@echo off
title Redz Mobile QA Toolkit
color 0A

set BASE=C:\MobileTesting
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set TS=%%i

set SESSION=%BASE%\%TS%
set LOGDIR=%SESSION%\Logs
set SHOTDIR=%SESSION%\Screenshots
set VIDEODIR=%SESSION%\Videos

mkdir "%LOGDIR%" >nul 2>&1
mkdir "%SHOTDIR%" >nul 2>&1
mkdir "%VIDEODIR%" >nul 2>&1

cd /d C:\scrcpy-win64-v4.0

echo Starting ADB...
adb start-server >nul 2>&1

set FOUND=
for /f "skip=1 tokens=1,2" %%A in ('adb devices') do (
    if "%%B"=="device" (
        set FOUND=1
        set DEV=%%A
    )
)

if not defined FOUND (
    echo.
    echo =====================================
    echo NO ANDROID DEVICE DETECTED
    echo =====================================
    echo Connect phone, enable:
    echo  - File Transfer
    echo  - USB Debugging
    echo  - Allow USB debugging
    echo.
    pause
    exit /b
)

echo Device: %DEV%
echo Session: %SESSION%
echo.

start "ADB Logcat" cmd /k adb logcat ^> "%LOGDIR%\logcat.txt"

echo Starting screen recording...
start "Screen Recording" cmd /k adb shell screenrecord /sdcard/qa_record.mp4

echo Opening evidence folder...
start "" explorer "%SESSION%"

echo Launching scrcpy...
scrcpy.exe

echo.
echo scrcpy closed.
echo.
echo To retrieve recording after stopping it on the phone or with Ctrl+C in the recording window:
echo adb pull /sdcard/qa_record.mp4 "%VIDEODIR%\qa_record.mp4"
echo.
pause
